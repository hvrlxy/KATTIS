#include <iostream>
using namespace std;

int main() {
	cout << "Somemisplacedstring";
	return 0;
}
